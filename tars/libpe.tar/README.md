libpe
=====

The PE library

[![Build Status](https://travis-ci.org/merces/libpe.png)](https://travis-ci.org/merces/libpe)

[![LGPL](http://www.gnu.org/graphics/lgplv3-147x51.png)](http://www.gnu.org/licenses/lgpl.html)